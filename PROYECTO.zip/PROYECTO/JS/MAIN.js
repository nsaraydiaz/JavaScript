// PRODUCTOS
const productos = [
    // ELEMENTOS DE PROTECCION
    {
        id: "elementos de proteccion-01",
        titulo: "Guante de nitrilo",
        imagen: "https://www.provesi.com.co/4030-large_default/guante-multiflex-polyester-nitrilo-negro-steelpro.jpg",
        categoria: {
            nombre: "Elementos de proteccion",
            id: "Elementos de proteccion"
        },
        precio: 5400
    },
    {
        id: "elementos de proteccion 02",
        titulo: "Gafas de seguridad",
        imagen: "https://www.imposeg.com/cdn/shop/products/31_6e32d172-fd81-4ce1-a579-a755b910ab3a_2048x.png?v=1598666413",
        categoria: {
            nombre: "Elementos de proteccion",
            id: "Elementos de proteccion"
        },
        precio: 4700
    },
    {
        id: "elementos de proteccion -03",
        titulo: "TAPAODIOS TIPO COPA",
        imagen: "https://mundoindustrial.co/wp-content/uploads/2021/05/Tapaoidos-Tipo-Copa-Samurai-Steelpro.jpg",
        categoria: {
            nombre: "Elementos de proteccion",
            id: "Elementos de proteccion"
        },
        precio: 42000
    },
    {
        id: "elementos de proteccion-04",
        titulo: "CASCO DE SEGURIDAD",
        imagen: "https://redsuministros.com/wp-content/uploads/2020/01/3M_H-702R.jpg",
        categoria: {
            nombre: "Elementos de proteccion",
            id: "Elementos de proteccion"
        },
        precio: 39200
    },
    
    // Vestuario de Seguridad
    {
        id: "vestuario-01",
        titulo: "OVEROL DRILL",
        imagen: "https://seguridadindustrialymedica.com/wp-content/uploads/2021/05/overol-azul-manga-larga.jpg",
        categoria: {
            nombre: "vestuario",
            id: "vestuario"
        },
        precio: 45000
    },
    {
        id: "vestuario-02",
        titulo: "Chaleco Reflectivo",
        imagen: "https://soefecepp.com/wp-content/uploads/2023/02/PC-Chaleco-Reflectivo-Verde-2.jpg",
        categoria: {
            nombre: "vestuario",
            id: "vestuario"
        },
        precio: 28700
    },
    {
        id: "vestuario-03",
        titulo: "Peto de carnaza",
        imagen: "https://soefecepp.com/wp-content/uploads/2023/02/PC-Peto-en-Vaqueta-de-Cuero.jpg",
        categoria: {
            nombre: "vestuario",
            id: "vestuario"
        },
        precio: 41988
    },
    {
        id: "vestuario-04",
        titulo: "Pava de proteccion",
        imagen: "https://www.cedicol.com.co/wp-content/uploads/2023/10/Pava-en-dril-para-casco-con-sombra-atras.jpg",
        categoria: {
            nombre: "vestuario",
            id: "vestuario"
        },
        precio: 1502290
    },

    // Calzado de seguridad
    {
        id: "Calzado-01",
        titulo: "Botas dielectricas",
        imagen: "https://soefecepp.com/wp-content/uploads/2022/10/PC-Bota-de-seguridad-dielectrica.jpg",
        categoria: {
            nombre: "Calzado",
            id: "Calzado"
        },
        precio: 45000
    },
    {
        id: "accesorio-02",
        titulo: "Bota punta de acero",
        imagen: "https://mundoindustrial.co/wp-content/uploads/2021/04/bota-dielectrica-3025-negra-701-NC-colombia-2023.jpg",
        categoria: {
            nombre: "Calzado",
            id: "Calzado"
        },
        precio: 650000
    },
    {
        id: "Calzado-03",
        titulo: "Bota de Seguridad",
        imagen: "https://www.provesi.com.co/3941-large_default/bota-seguridad-saga-cuero-graso-cana-alta-10-pulg-cafe-bidensidad-pu-soldador-3046.jpg",
        categoria: {
            nombre: "Calzado",
            id: "Calzado"
        },
        precio: 169000
    },
    {
        id: "accesorio-04",
        titulo: "Bota de seguridad tipo Ingeniero",
        imagen: "https://cycsupplies.com/wp-content/uploads/2022/09/Iron.png",
        categoria: {
            nombre: "Calzado",
            id: "Calzado"
        },
        precio: 238000
    }

];

const contenedorProductos = document.querySelector("#contenedor-productos");
const botonesCategorias = document.querySelectorAll(".boton-categoria");
const tituloPrincipal = document.querySelector("#titulo-principal");
let botonesAgregar = document.querySelectorAll(".producto-agregar");
const numerito = document.querySelector("#numerito");

function cargarProductos(productosElegidos) {

    contenedorProductos.innerHTML = "";

    productosElegidos.forEach(producto => {

        const div = document.createElement("div");
        div.classList.add("producto");
        div.innerHTML = `
            <img class="producto-imagen" src="${producto.imagen}" alt="${producto.titulo}">
            <div class="producto-detalles">
                <h3 class="producto-titulo">${producto.titulo}</h3>
                <p class="producto-precio">$${producto.precio}</p>
                <button class="producto-agregar" id="${producto.id}">Agregar</button>
            </div>
        `;

        contenedorProductos.append(div);
    })

    actualizarBotonesAgregar();
}

cargarProductos(productos);

botonesCategorias.forEach(boton => {
    boton.addEventListener("click", (e) => {

        botonesCategorias.forEach(boton => boton.classList.remove("active"));
        e.currentTarget.classList.add("active");

        if (e.currentTarget.id != "todos") {
            const productoCategoria = productos.find(producto => producto.categoria.id === e.currentTarget.id);
            tituloPrincipal.innerText = productoCategoria.categoria.nombre;
            const productosBoton = productos.filter(producto => producto.categoria.id === e.currentTarget.id);
            cargarProductos(productosBoton);
        } else {
            tituloPrincipal.innerText = "Todos los productos";
            cargarProductos(productos);
        }

    })
});

function actualizarBotonesAgregar() {
    botonesAgregar = document.querySelectorAll(".producto-agregar");

    botonesAgregar.forEach(boton => {
        boton.addEventListener("click", agregarAlCarrito);
    });
}

let productosEnCarrito;

let productosEnCarritoLS = localStorage.getItem("productos-en-carrito");

if (productosEnCarritoLS) {
    productosEnCarrito = JSON.parse(productosEnCarritoLS);
    actualizarNumerito();
} else {
    productosEnCarrito = [];
}

function agregarAlCarrito(e) {
    const idBoton = e.currentTarget.id;
    const productoAgregado = productos.find(producto => producto.id === idBoton);

    if(productosEnCarrito.some(producto => producto.id === idBoton)) {
        const index = productosEnCarrito.findIndex(producto => producto.id === idBoton);
        productosEnCarrito[index].cantidad++;
    } else {
        productoAgregado.cantidad = 1;
        productosEnCarrito.push(productoAgregado);
    }

    actualizarNumerito();

    localStorage.setItem("productos-en-carrito", JSON.stringify(productosEnCarrito));
}

function actualizarNumerito() {
    let nuevoNumerito = productosEnCarrito.reduce((acc, producto) => acc + producto.cantidad, 0);
    numerito.innerText = nuevoNumerito;
}
