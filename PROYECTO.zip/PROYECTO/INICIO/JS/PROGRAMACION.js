// PROGRAMACION DE TRANSCION DE AMBOS FORMULARIOS
const signUpButton=document.getElementById("signUp");//registro
const signInButton=document.getElementById("signIn");//ingreso
const container=document.getElementById("container")
const boost=document.getElementById("boost");
//evento click de mostrar form registro
signUpButton.addEventListener(`click`, ()=>{
    container.classList.add("right-panel-active");
    boost.style.visibility="hidden";
});
//evento click de ocultar form registro
signUpButton.addEventListener(`click`, ()=>{
    container.classList.remove("right-panel-active");
    boost.style.visibility="visible";
});
//Mostrar contraseña
function mostrarSeña(){
    var tipo=document.getElementById("seña");
    if(tipo.type=="password"){
        tipo.type="text";
    }else{
        tipo.type="password";
    }
}